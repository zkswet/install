<?php get_header(); ?>
<?php if(have_posts()) : ?>
	<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
 	  <?php /* If this is a category archive */ if (is_category()) { ?>
		<h2>Archive for the <span class="kunci"><?php single_cat_title(); ?></span> Category</h2>
 	  <?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
		<h2>Posts Tagged <span class="kunci"><?php single_tag_title(); ?></span></h2>
 	  <?php /* If this is a daily archive */ } elseif (is_day()) { ?>
		<h2>Archive for <span class="kunci"><?php the_time('F jS, Y'); ?></span></h2>
 	  <?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
		<h2>Archive for <span class="kunci"><?php the_time('F, Y'); ?></span></h2>
 	  <?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
		<h2>Archive for <span class="kunci"><?php the_time('Y'); ?></span></h2>
	  <?php /* If this is an author archive */ } elseif (is_author()) { ?>
		<h2>Author Archive</h2>
 	  <?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h2>Blog Archives</h2>
 	  <?php } ?>
<ul>
<?php while(have_posts()) : the_post(); ?>
<li><h3><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h3>
Posted in <?php the_category(', ') ?> - <a href="<?php the_permalink(); ?>"><?php the_time('j F Y'); ?></a> - <?php comments_number('No comment', '1 comment', '% comments'); ?></li>
<?php endwhile; ?>
</ul>
<div class="page-nav">
<span class="older"><?php next_posts_link('&laquo; Previous Articles') ?></span><span class="newer"><?php previous_posts_link('Next Articles &raquo;') ?></span>
<div class="clear"></div>
</div><!-- end page-nav -->
<?php else : ?>
		<?php if ( is_category() ) { // If this is a category archive
			printf("<h2>Sorry, but there aren't any posts in the %s category yet.</h2>", single_cat_title('',false));
		} else if ( is_date() ) { // If this is a date archive
			echo("<h2>Sorry, but there aren't any posts with this date.</h2>");
		} else if ( is_author() ) { // If this is a category archive
			echo("<h2>Sorry, but there aren't any posts by this author yet.</h2>");
		} else {
			echo("<h2>No posts found.</h2>");
		} ?>
<?php endif; ?>
</div><!-- end main-content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>