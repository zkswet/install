<?php
global $options;
foreach ($options as $value) {
    if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); }
}
?>

<div class="clear"></div>

<div id="footer">
<div id="foot-1">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Left') ) : ?>

<div class="widget">
<h4>Meta</h4>
	<ul>
		<?php wp_register(); ?>
		<li><?php wp_loginout(); ?></li>
		<?php wp_meta(); ?>
	</ul>
</div>

<?php endif; ?>
</div><!-- end foot-1 -->

<div id="foot-right">
<div id="foot-2">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Center') ) : ?>
<div class="widget">
<h4>Archives</h4>
<ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
</div>
<?php endif; ?>
</div><!-- end foot-2 -->

<div id="foot-3">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Footer Right') ) : ?>
<div class="widget">
<h4>Pages</h4>
<ul>
<?php wp_list_pages('depth=1&sort_column=menu_order&title_li='); ?>
</ul>
</div>
<?php endif; ?>
</div><!-- end foot-3 -->
<div class="clear"></div>
</div><!-- end foot-right -->
<div class="clear"></div>
</div><!-- end footer -->

<div id="footer-credit">
Copyright &copy; <?php echo date("Y") ?> <b><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></b>. <a href="<?php bloginfo('rss2_url'); ?>">Entries (RSS)</a> <a href="http://mazznoer.web.id/">Mazznoer</a>. <a href="http://wordpress.org/">WordPress</a>.
<div id="footer-desc"><?php bloginfo('description'); ?></div>
</div><!-- end footer-credit -->

</div><!-- end div #container -->
</div><!-- end div #wrapper -->

<?php

wp_footer();

if (!empty($cleansimplewhite_tracking_code)) {
	echo(stripslashes($cleansimplewhite_tracking_code));
}

?>

</body>
</html>
