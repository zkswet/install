<?php
global $options;
foreach ($options as $value) {
	if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<?php
$favicon = $cleansimplewhite_favicon;
echo '<link rel="shortcut icon" href="';
	if (!empty($favicon)) {
		echo "$favicon";
	} else {
		echo bloginfo('template_directory').'/favicon.ico';
	}
echo '" />';
?>

<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" media="screen" />
<?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div id="wrapper">
<div id="container">
<div id="header">
<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
<div id="head-desc"><?php bloginfo('description'); ?></div>
</div><!-- end header -->

<div id="head-nav">
<?php wp_nav_menu(array('theme_location' => 'primary')); ?>
<div class="clear"></div>
</div><!-- end head-nav -->

<div id="main-content">