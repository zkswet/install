<?php
global $options;
foreach ($options as $value) {
    if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; } else { $$value['id'] = get_option( $value['id'] ); }
}
?>

<div id="sidebar">
<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>

<div class="widget">
<?php get_search_form(); ?>
</div>

<?php if (is_home()): ?>
<?php else: ?>
<div class="widget">
<h4>Recent Posts</h4>
<?php query_posts('showposts=7'); ?>
<ul>
<?php while (have_posts()) : the_post(); ?>
<li><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></li>
<?php endwhile;?>
</ul>
</div>
<?php endif; ?>

<div class="widget">
<h4>Categories</h4>
<ul>
<?php wp_list_categories('sort_column=name&depth=1&title_li='); ?>
</ul>
</div>

<div class="widget">
<h4>Calendar</h4>
<?php get_calendar(); ?>
</div>

<?php endif; ?>
</div><!-- end sidebar -->