<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/"><div class="search-box">
<input type="text" value="search this site" name="s" id="s" onfocus="if (this.value == 'search this site') {this.value = '';}" onblur="if (this.value == '') {this.value = 'search this site';}" />
<input type="submit" id="searchsubmit" value="Search" />
</div></form>