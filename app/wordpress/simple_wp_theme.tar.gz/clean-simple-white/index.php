<?php get_header(); ?>
<?php if(have_posts()) : ?>
<?php while(have_posts()) : the_post(); ?>
<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
<div class="post-meta">Posted in <?php the_category(', ') ?> - <a href="<?php the_permalink(); ?>"><?php the_time('j F Y') ?></a> - <?php comments_number('No comment', '1 comment', '% comments'); ?></div>

 <?php if(is_category() || is_archive() || is_home() ) {
     the_excerpt();
 } else {
     the_content('Read the rest of this entry &raquo;'); 
 } ?>
 <div class="details"><div class="inside"><?php comments_popup_link('No Comments', '1 Comment', '% Comments'); ?> so far | <a href="<?php the_permalink() ?>">Read On &raquo;</a></div></div>

<?php wp_link_pages(array('before' => '<p class="page-link"><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number', 'pagelink' => '<span>%</span>')); ?>
</div>
<div class="clear post-spt"></div>
<?php endwhile; ?>
<div class="page-nav">
<span class="older"><?php next_posts_link('&laquo; Previous Articles') ?></span><span class="newer"><?php previous_posts_link('Next Articles &raquo;') ?></span>
<div class="clear"></div>
</div><!-- end page-nav -->

<?php else : ?>
<h2>Woops...</h2>
<?php endif; ?>

</div><!-- end main-content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
